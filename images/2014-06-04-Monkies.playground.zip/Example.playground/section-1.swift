import UIKit

var monkies: String[] = []

let Mizaru = "🙈"
let Kikazaru = "🙉"
let Iwazaru = "🙊"

monkies += Mizaru
monkies += Kikazaru
monkies += Iwazaru

for monkey in monkies {
    sleep(1)
    NSLog(monkey)
}






